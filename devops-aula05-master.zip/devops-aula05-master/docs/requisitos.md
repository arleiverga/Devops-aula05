#requisitos
Criar uma estrutura de dados...etc
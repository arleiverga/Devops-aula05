#Arquitetura
Função relacionada ao gerencianento das casas do jogo da velha... etc